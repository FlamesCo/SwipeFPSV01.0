import java.awt.*;
import java.awt.event.*;
 
import javax.swing.*;

public class SwipeFPSV0 {
    private JFrame frame;
    private JTextField originalFileField;
    private JTextField patchFileField;
    private JButton originalFileButton;
    private JButton patchFileButton;
    private JButton patchButton;
    private JProgressBar progressBar;

    public static void main(String[] args) {
        SwipeFPSV0 app = new SwipeFPSV0();
        app.createAndShowGUI();
    }

    private void createAndShowGUI() {
        frame = new JFrame("SwipeFPS - IPS Patcher");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(5, 5, 5, 5);
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;

        JLabel originalFileLabel = new JLabel("Original File:");
        frame.add(originalFileLabel, constraints);

        originalFileField = new JTextField(20);
        constraints.gridx = 1;
        constraints.gridwidth = 2;
        frame.add(originalFileField, constraints);

        originalFileButton = new JButton("...");
        originalFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(frame);
                if (result == JFileChooser.APPROVE_OPTION) {
                    originalFileField.setText(fileChooser.getSelectedFile().getAbsolutePath());
                }
            }
        });
        constraints.gridx = 3;
        constraints.gridwidth = 1;
        frame.add(originalFileButton, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;

        JLabel patchFileLabel = new JLabel("Patch File:");
        frame.add(patchFileLabel, constraints);

        patchFileField = new JTextField(20);
        constraints.gridx = 1;
        constraints.gridwidth = 2;
        frame.add(patchFileField, constraints);

        patchFileButton = new JButton("...");
        patchFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(frame);
                if (result == JFileChooser.APPROVE_OPTION) {
                    patchFileField.setText(fileChooser.getSelectedFile().getAbsolutePath());
                }
            }
        });
        constraints.gridx = 3;
        constraints.gridwidth = 1;
        frame.add(patchFileButton, constraints);

        patchButton = new JButton("Patch");
        patchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        frame.add(patchButton, constraints);

        progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 4;
        frame.add(progressBar, constraints);

        frame.setVisible(true);
    }
}
